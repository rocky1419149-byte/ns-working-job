// Firebase modular Web SDK starter. Replace the placeholder config with your own
// Firebase Console > Project settings > Your apps > Web app config.
// Do not put private service-account keys in browser code.
import { initializeApp } from "https://www.gstatic.com/firebasejs/11.10.0/firebase-app.js";
import {
  getAuth, RecaptchaVerifier, signInWithPhoneNumber, onAuthStateChanged, signOut
} from "https://www.gstatic.com/firebasejs/11.10.0/firebase-auth.js";
import {
  getFirestore, doc, getDoc, setDoc, collection, addDoc, query,
  orderBy, onSnapshot, serverTimestamp, runTransaction
} from "https://www.gstatic.com/firebasejs/11.10.0/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "PASTE_API_KEY_HERE",
  authDomain: "PASTE_PROJECT_ID.firebaseapp.com",
  projectId: "PASTE_PROJECT_ID",
  appId: "PASTE_APP_ID_HERE"
};

const configIsPlaceholder = Object.values(firebaseConfig).some(v => String(v).includes("PASTE_"));
const authStatus = document.querySelector("#auth-status");
const $ = (s) => document.querySelector(s);
let app, auth, db, confirmationResult, currentUser, captcha;
let profile = null;

function setStatus(message) { authStatus.textContent = message; }
function show(el, yes=true) { el.classList.toggle("hidden", !yes); }

if (configIsPlaceholder) {
  setStatus("শুরু করার আগে app.js ফাইলে Firebase Web App config বসাতে হবে।");
} else {
  app = initializeApp(firebaseConfig);
  auth = getAuth(app);
  db = getFirestore(app);
  captcha = new RecaptchaVerifier(auth, "recaptcha-container", { size: "normal" });

  onAuthStateChanged(auth, async (user) => {
    currentUser = user;
    show($("#profile-card"), !!user);
    show($("#logout"), !!user);
    show($("#withdraw-card"), !!user);
    if (!user) {
      profile = null;
      show($("#seller-card"), false);
      setStatus("লগইন করা হয়নি।");
      $("#tasks").innerHTML = "<p>কাজ দেখতে লগইন আবশ্যক নয়।</p>";
      return;
    }
    setStatus("লগইন সফল হয়েছে।");
    $("#user-info").textContent = `লগইন নম্বর: ${user.phoneNumber || "অজানা"}`;
    const ref = doc(db, "users", user.uid);
    const snap = await getDoc(ref);
    if (!snap.exists()) {
      profile = { role: "worker", balance: 0 };
      await setDoc(ref, { role: "worker", balance: 0, phoneNumber: user.phoneNumber || "", createdAt: serverTimestamp() });
    } else {
      profile = snap.data();
    }
    $("#role").value = profile.role || "worker";
    $("#balance").textContent = Number(profile.balance || 0).toLocaleString("en-US");
    show($("#seller-card"), profile.role === "seller");
  });
  listenTasks();
}

$("#send-code").addEventListener("click", async () => {
  if (configIsPlaceholder) return setStatus("আগে Firebase config বসান।");
  const phone = $("#phone").value.trim();
  if (!/^\+[1-9]\d{7,14}$/.test(phone)) return setStatus("দেশের কোডসহ সঠিক নম্বর দিন, যেমন +8801XXXXXXXXX।");
  try {
    confirmationResult = await signInWithPhoneNumber(auth, phone, captcha);
    setStatus("OTP পাঠানো হয়েছে। SMS-এর কোড লিখুন।");
  } catch (e) {
    setStatus(`OTP পাঠানো যায়নি: ${e.message}`);
  }
});

$("#verify-code").addEventListener("click", async () => {
  if (!confirmationResult) return setStatus("আগে OTP পাঠান।");
  try {
    await confirmationResult.confirm($("#otp").value.trim());
    setStatus("লগইন সফল হয়েছে।");
  } catch (e) {
    setStatus("OTP যাচাই হয়নি। কোড দেখে আবার চেষ্টা করুন।");
  }
});

$("#logout").addEventListener("click", async () => { if (auth) await signOut(auth); });
$("#save-profile").addEventListener("click", async () => {
  if (!currentUser || !db) return;
  const role = $("#role").value;
  // Role changes are user-editable in this demo. A production app must restrict
  // admin roles and enforce authorization with trusted backend/security rules.
  await setDoc(doc(db, "users", currentUser.uid), { role }, { merge: true });
  profile = { ...(profile || {}), role };
  show($("#seller-card"), role === "seller");
  setStatus("অ্যাকাউন্টের ধরন সংরক্ষিত হয়েছে।");
});

$("#post-task").addEventListener("click", async () => {
  if (!currentUser || !db || profile?.role !== "seller") return;
  const title = $("#task-title").value.trim();
  const description = $("#task-description").value.trim();
  const points = Number($("#task-points").value);
  if (!title || !description || !Number.isInteger(points) || points < 1 || points > 10000) {
    return alert("কাজের নাম, বিবরণ ও ১–১০০০০-এর মধ্যে পূর্ণসংখ্যা পয়েন্ট দিন।");
  }
  await addDoc(collection(db, "tasks"), {
    title, description, points, sellerUid: currentUser.uid,
    status: "open", createdAt: serverTimestamp()
  });
  $("#task-title").value = "";
  $("#task-description").value = "";
  alert("ডেমো কাজ পোস্ট হয়েছে।");
});

function listenTasks() {
  const q = query(collection(db, "tasks"), orderBy("createdAt", "desc"));
  onSnapshot(q, (snapshot) => {
    const root = $("#tasks");
    root.innerHTML = "";
    if (snapshot.empty) { root.innerHTML = "<p>এখনো কোনো কাজ পোস্ট হয়নি।</p>"; return; }
    snapshot.forEach((taskDoc) => {
      const t = taskDoc.data();
      const item = document.createElement("article");
      item.className = "task";
      const title = document.createElement("h3"); title.textContent = t.title || "কাজ";
      const desc = document.createElement("p"); desc.textContent = t.description || "";
      const meta = document.createElement("p"); meta.innerHTML = `<span class="pill">পয়েন্ট: ${Number(t.points || 0)}</span> <span class="pill">${t.status === "open" ? "খোলা" : "বন্ধ"}</span>`;
      item.append(title, desc, meta);
      if (currentUser && profile?.role === "worker" && t.status === "open") {
        const btn = document.createElement("button");
        btn.textContent = "কাজ সম্পন্নের অনুরোধ";
        btn.addEventListener("click", async () => {
          await addDoc(collection(db, "taskSubmissions"), {
            taskId: taskDoc.id, workerUid: currentUser.uid, sellerUid: t.sellerUid,
            status: "pending", createdAt: serverTimestamp()
          });
          alert("অনুরোধ জমা হয়েছে। এটি শুধু ডেমো; পয়েন্ট স্বয়ংক্রিয়ভাবে যোগ হবে না।");
        });
        item.append(btn);
      }
      root.append(item);
    });
  }, (err) => { $("#tasks").textContent = `কাজ লোড হয়নি: ${err.message}`; });
}

$("#request-withdraw").addEventListener("click", async () => {
  if (!currentUser || !db) return;
  const amount = Number($("#withdraw-amount").value);
  const method = $("#withdraw-method").value;
  const number = $("#withdraw-number").value.trim();
  if (!Number.isInteger(amount) || amount < 1 || !/^01\d{9}$/.test(number)) {
    $("#withdraw-status").textContent = "সঠিক পরিমাণ এবং ১১ সংখ্যার 01XXXXXXXXX নম্বর দিন।";
    return;
  }
  await addDoc(collection(db, "withdrawRequests"), {
    uid: currentUser.uid, amount, method, number, status: "pending", createdAt: serverTimestamp()
  });
  $("#withdraw-status").textContent = "ডেমো অনুরোধ জমা হয়েছে; এটি টাকা পাঠায় না।";
});
